import Comment from './Comment.js';
var CommentBox = React.createClass({
            getInitialState:function(){
                     return {data:[]}
                   },
             componentDidMount:function(){
                     this.setState({data:[
                         {author:'高山',text:'最近好吗？'},
                         {author:'高山',text:'最近好吗？'},
                         {author:'流水',text:'very good：-）'}
                     ]});
             },
             submit:function(comment){
                var newcomment = this.state.data.concat(comment);
                this.setState({data:newcomment});
             },
             render: function() {
               return (
                 <div className="commentBox">
			           <CommentList data={this.state.data} xxx={this.state.xxx} />
			           <CommentForm commentSubmit = {this.submit}/>
                 </div>
               );
             }
           });
	var CommentList = React.createClass({
          render: function() {
            function __aaa(newarr,index){
              return (
                <Comment author={newarr.author}>{newarr.text}</Comment>
              )
            }
            var CommentNode = this.props.data.map(__aaa);
            console.log(this.props.xxx)
            return (
              <div className="commentList">
              <ul className="comment">
                {CommentNode}
              </ul>
              </div>
            );
          }
        });	

        var CommentForm = React.createClass({
          confirm:function(e){
            e.preventDefault();
            this.props.commentSubmit({author:this.refs.author.value,text:this.refs.text.value});
              this.refs.author.value = '';
              this.refs.text.value = '';
          },
          render: function() {
            return (
              <div className="commentForm">
                <form className="myForm" onSubmit={this.confirm}>
                <input type="text" placeholder="Your Name" ref="author" />
                <input type="text" placeholder="Say Something ..." ref="text" />
                <input type="submit" value="确定" />
              </form>
              </div>
            );
          }
        });	
          ReactDOM.render(
          <CommentBox  xxx="1" />,
          document.getElementById('content')
		);
