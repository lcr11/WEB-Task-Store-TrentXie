import Comment from './Comment.js';
class CommentList extends React.Component{
          render() {
            function __aaa(newarr,index){
              return (
                <Comment author={newarr.author}>{newarr.text}</Comment>
              )
            }
            var CommentNode = this.props.data.map(__aaa);
            console.log(this.props.xxx)
            return (
              <div className="commentList">
              <ul className="comment">
                {CommentNode}
              </ul>
              </div>
            );
          }
        };	
export default CommentList;
