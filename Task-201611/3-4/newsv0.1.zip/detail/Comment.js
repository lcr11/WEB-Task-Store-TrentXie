	class Comment extends React.Component{
		render(){
			return (
				<li className="commentAuthor">{this.props.author}：{this.props.children}</li>
			);	
		}
	}
export default Comment
