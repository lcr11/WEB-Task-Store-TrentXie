import '../asset/style/global.css';
//import '../js/template.js';
//import qqlogo from  '../asset/js';
//console.log(qqlogo);
//$('body').html('<img src="'+qqlogo+'">');

import './detail.js';
//import './operate';
//import './test_component';
//console.log(qqlogo)
/*import '../asset/style/style1.css';
import '../asset/style/style1.debug.css';
class CommentBox extends React.Component{
			constructor () {
				super();
				this.state = {
					data:[]
				}
			}
             componentDidMount = () => {
                     this.setState({data:[
                         {author:'高山',text:'最近好吗？'},
                         {author:'高山',text:'最近好吗？'},
                         {author:'流水',text:'very good：-）'}
                     ]});
             }
             submit =(comment)=>{
console.log(this)
                var newcomment = this.state.data.concat(comment);
                this.setState({data:newcomment});
             }
             render() {
               return (
	<section>
		<ul>
			<li>
				<h2>
					<a href="">最美自主车致尚XT竞争力分析--这里是测试文字的地方</a>
				</h2>
				<div className="about">
					<time>07-04 06:30  </time>
					<span className="author">搜狐汽车</span>
				</div>
			</li>
			<li>
				<h2>
					<a href="">最美自主车致尚XT竞争力分析--这里是测试文字的地方</a>
				</h2>
				<div className="about">
					<time>07-04 06:30  </time>
					<span className="author">搜狐汽车</span>
				</div>
			</li>
			<li>
				<h2>
					<a href="">最美自主车致尚XT竞争力分析--这里是测试文字的地方</a>
				</h2>
				<div className="about">
					<time>07-04 06:30  </time>
					<span className="author">搜狐汽车</span>
				</div>
			</li>
			<li>
				<h2>
					<a href="">最美自主车致尚XT竞争力分析--这里是测试文字的地方</a>
				</h2>
				<div className="about">
					<time>07-04 06:30  </time>
					<span className="author">搜狐汽车</span>
				</div>
			</li>
			<li>
				<h2>
					<a href="">最美自主车致尚XT竞争力分析--这里是测试文字的地方</a>
				</h2>
				<div className="about">
					<time>07-04 06:30  </time>
					<span className="author">搜狐汽车</span>
				</div>
			</li>
			<li>
				<h2>
					<a href="">最美自主车致尚XT竞争力分析--这里是测试文字的地方</a>
				</h2>
				<div className="about">
					<time>07-04 06:30  </time>
					<span className="author">搜狐汽车</span>
				</div>
			</li>
		</ul>
		<div className="loading">加载中</div>
		<a href="#" className="returntop"><i></i>返回顶部</a>
	</section>
               );
             }
           };


    ReactDOM.render(
          <CommentBox  />,
          document.getElementById('content')
		);
*/
